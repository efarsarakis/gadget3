
#include "allvars.h"

int DesLinkNgb;

char OutputDir[500];
