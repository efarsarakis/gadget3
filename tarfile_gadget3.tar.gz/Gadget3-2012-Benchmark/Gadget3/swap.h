#ifndef SWAP_H
#define SWAP_H

double SwapDouble( double Val );
float SwapFloat( float Val );
int SwapInt( int Val );
int CheckSwap( char* fname, int *swap );

#endif /* SWAP_H */
